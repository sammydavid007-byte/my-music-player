(() => {
  'use strict';

  // Paste your own Jamendo Client ID here (from devportal.jamendo.com).
  const CLIENT_ID = 'YOUR_JAMENDO_CLIENT_ID';
  const API = 'https://api.jamendo.com/v3.0';
  const PREFIX = 'jamendo_cc:song:';
  const PAGE_SIZE = 24;

  function ok(data) { return { ok: true, data: JSON.stringify(data) }; }
  function fail(message) {
    return { ok: false, error: { message: String(message || 'Jamendo unavailable') } };
  }

  function configured() {
    return CLIENT_ID && CLIENT_ID !== 'YOUR_JAMENDO_CLIENT_ID';
  }

  async function jamendoGet(path, params) {
    const query = Object.keys(params)
      .filter(k => params[k] !== undefined && params[k] !== '')
      .map(k => encodeURIComponent(k) + '=' + encodeURIComponent(params[k]))
      .join('&');
    const url = API + path + '?client_id=' + encodeURIComponent(CLIENT_ID) +
      '&format=json&' + query;
    try {
      const res = await fetch(url, {
        method: 'GET',
        headers: { 'Accept': 'application/json' },
        timeoutMs: 8000
      });
      if (res.status !== 200) return null;
      const body = await res.json();
      if (!body || !body.headers || body.headers.status !== 'success') return null;
      return Array.isArray(body.results) ? body.results : null;
    } catch (_) {
      return null;
    }
  }

  function safeHttps(url) {
    const value = String(url || '').trim();
    return /^https:\/\//i.test(value) ? value : '';
  }

  // Only tracks the artist allows to be downloaded are exposed, so every
  // listed track is consistent with the offline-download flag.
  function usable(item) {
    return item && item.id && item.name &&
      item.audiodownload_allowed === true && !!safeHttps(item.audio);
  }

  function toTrack(item) {
    if (!usable(item)) return null;
    const id = String(item.id);
    return {
      id: PREFIX + id,
      href: PREFIX + id,
      type: 'track',
      title: String(item.name),
      artist: String(item.artist_name || 'Unknown Artist'),
      album: item.album_name ? String(item.album_name) : undefined,
      albumId: item.album_id ? 'album:' + item.album_id : undefined,
      image: safeHttps(item.image || item.album_image) || undefined,
      durationSeconds: Number(item.duration) || undefined
    };
  }

  function providerId(trackId) {
    const value = String(trackId || '').trim();
    if (value.startsWith(PREFIX)) return value.slice(PREFIX.length).trim();
    return /^\d+$/.test(value) ? value : '';
  }

  async function searchResults(query, page) {
    if (!configured()) return fail('Add your Jamendo Client ID to index.js.');
    const term = String(query || '').trim();
    if (!term) return ok([]);
    const pageIndex = Math.max(0, Math.min(59, Math.floor(Number(page) || 0)));
    const rows = await jamendoGet('/tracks/', {
      search: term,
      limit: PAGE_SIZE,
      offset: pageIndex * PAGE_SIZE,
      audiodownload_allowed: 'true',
      imagesize: 300,
      order: 'relevance'
    });
    if (!rows) return fail('Jamendo search failed. Retry.');
    return ok(rows.map(toTrack).filter(Boolean));
  }

  async function homeSections(page) {
    if (Number(page) > 0) return ok([]);
    if (!configured()) return fail('Add your Jamendo Client ID to index.js.');
    const sections = [];
    const lists = [
      { title: 'Popular This Week', order: 'popularity_week' },
      { title: 'Popular This Month', order: 'popularity_month' }
    ];
    for (const list of lists) {
      const rows = await jamendoGet('/tracks/', {
        limit: PAGE_SIZE,
        order: list.order,
        audiodownload_allowed: 'true',
        imagesize: 300
      });
      const items = (rows || []).map(toTrack).filter(Boolean).slice(0, 12);
      if (items.length) sections.push({ title: list.title, type: 'track', items });
    }
    return sections.length ? ok(sections) : fail('Jamendo discovery is unavailable.');
  }

  // ---- Catalogue ids -------------------------------------------------------
  // The app can save a track as "catalogue:" + base64("title\0artist") and ask
  // the selected source to find it. Match strictly on title and artist.
  function base64ToBytes(b64) {
    const input = String(b64 || '').trim();
    if (!input || input.length > 8192 || !/^[A-Za-z0-9+/]*={0,2}$/.test(input)) return null;
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    const str = input.replace(/=+$/, '');
    if (str.length % 4 === 1) return null;
    const bytes = [];
    let buffer = 0, bits = 0;
    for (let i = 0; i < str.length; i++) {
      buffer = (buffer << 6) | chars.indexOf(str[i]);
      bits += 6;
      if (bits >= 8) { bits -= 8; bytes.push((buffer >> bits) & 0xff); }
    }
    return bytes;
  }

  function utf8Decode(bytes) {
    if (!bytes) return '';
    let out = '';
    for (let i = 0; i < bytes.length;) {
      const b = bytes[i++];
      let cp, need;
      if (b <= 0x7f) { cp = b; need = 0; }
      else if (b >= 0xc2 && b <= 0xdf) { cp = b & 0x1f; need = 1; }
      else if (b >= 0xe0 && b <= 0xef) { cp = b & 0x0f; need = 2; }
      else if (b >= 0xf0 && b <= 0xf4) { cp = b & 0x07; need = 3; }
      else return '';
      if (i + need > bytes.length) return '';
      for (let j = 0; j < need; j++) {
        const n = bytes[i++];
        if ((n & 0xc0) !== 0x80) return '';
        cp = (cp << 6) | (n & 0x3f);
      }
      if (cp > 0x10ffff) return '';
      if (cp <= 0xffff) out += String.fromCharCode(cp);
      else {
        const a = cp - 0x10000;
        out += String.fromCharCode(0xd800 + (a >> 10), 0xdc00 + (a & 0x3ff));
      }
    }
    return out;
  }

  function parseCatalogueId(trackId) {
    const clean = String(trackId || '').replace(/^catalogue:/, '').trim();
    const decoded = utf8Decode(base64ToBytes(clean));
    if (!decoded || decoded.indexOf('\u0000') === -1) return null;
    const parts = decoded.split('\u0000');
    const title = String(parts[0] || '').trim();
    const artist = String(parts[1] || '').trim();
    return title && artist ? { title, artist } : null;
  }

  function canon(value) {
    let text = String(value === undefined || value === null ? '' : value).trim();
    try { text = text.normalize('NFKC'); } catch (_) {}
    return text.toLowerCase().replace(/[^\p{L}\p{M}\p{N}]+/gu, ' ').trim().replace(/\s+/g, ' ');
  }

  function firstArtist(value) {
    const text = String(value || '');
    const m = text.match(/^(.*?)(?:,|&|\s+feat\.?|\s+ft\.?|\s+with\s+)/i);
    return canon(m ? m[1] : text);
  }

  async function findByCatalogue(wanted) {
    const wantedTitle = canon(wanted.title);
    const wantedArtist = firstArtist(wanted.artist);
    const attempts = [
      { namesearch: wanted.title, artist_name: wanted.artist },
      { namesearch: wanted.title }
    ];
    for (const extra of attempts) {
      const rows = await jamendoGet('/tracks/', Object.assign({
        limit: PAGE_SIZE, audiodownload_allowed: 'true'
      }, extra));
      if (!rows) continue;
      const hit = rows.find(item => usable(item) &&
        canon(item.name) === wantedTitle &&
        firstArtist(item.artist_name) === wantedArtist);
      if (hit) return hit;
    }
    return null;
  }

  function audioResult(item, quality) {
    const track = toTrack(item);
    return ok({
      url: safeHttps(item.audio),
      headers: {},
      mimeType: 'audio/mpeg',
      extension: 'mp3',
      title: track.title,
      artist: track.artist,
      album: track.album || '',
      artwork: track.image || '',
      durationSeconds: track.durationSeconds,
      quality: quality || 'high'
    });
  }

  async function extractAudioUrl(trackId, quality) {
    if (!configured()) return fail('Add your Jamendo Client ID to index.js.');
    const input = String(trackId || '').trim();

    if (input.startsWith('catalogue:')) {
      const wanted = parseCatalogueId(input);
      if (!wanted) return fail('Unrecognised catalogue id.');
      const item = await findByCatalogue(wanted);
      if (!item) return fail('This track is not available on Jamendo.');
      return audioResult(item, quality);
    }

    const id = providerId(input);
    if (!id) return fail('Unrecognised Jamendo track id.');
    const rows = await jamendoGet('/tracks/', { id: id, audioformat: 'mp32' });
    const item = rows && rows.find(row => String(row.id) === id);
    if (!item) return fail('Track not found.');
    if (!usable(item)) return fail('This track is not available for download.');
    return audioResult(item, quality);
  }

  async function extractDetails(id) {
    if (!configured()) return fail('Add your Jamendo Client ID to index.js.');
    const albumId = String(id || '').replace(/^(album|jamendo_cc):/, '').trim();
    if (!/^\d+$/.test(albumId)) return fail('Album details unavailable.');
    const rows = await jamendoGet('/albums/tracks/', { id: albumId, imagesize: 300 });
    const album = rows && rows[0];
    if (!album) return fail('Album details unavailable.');
    const tracks = (album.tracks || []).map(t => toTrack({
      ...t,
      album_name: album.name,
      album_id: album.id,
      artist_name: album.artist_name,
      image: t.image || album.image,
      audiodownload_allowed: t.audiodownload_allowed
    })).filter(Boolean);
    return ok({
      type: 'album',
      id: 'album:' + album.id,
      title: String(album.name),
      artist: String(album.artist_name || ''),
      image: safeHttps(album.image) || undefined,
      year: album.releasedate ? String(album.releasedate).slice(0, 4) : undefined,
      trackCount: tracks.length || undefined,
      releaseType: 'unknown',
      tracks
    });
  }

  async function extractTracks(containerId) {
    const details = await extractDetails(containerId);
    if (!details.ok) return details;
    return ok(JSON.parse(details.data).tracks || []);
  }

  async function getRelatedTracks() { return ok([]); }

  globalThis.searchResults = searchResults;
  globalThis.homeSections = homeSections;
  globalThis.extractDetails = extractDetails;
  globalThis.extractTracks = extractTracks;
  globalThis.extractAudioUrl = extractAudioUrl;
  globalThis.getRelatedTracks = getRelatedTracks;
})();
